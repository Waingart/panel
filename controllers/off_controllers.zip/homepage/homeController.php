<?
include('tpl/nakrutka4y.html');