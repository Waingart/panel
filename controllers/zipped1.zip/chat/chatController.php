<?
//include('chatView.php');