<?if(!defined('ALLOW_RUN')) { // Запрещаем прямое обращение к файлу
  header('Location: /'); 
  exit();
}


$users = new users();

switch ($URI_TO_CTL[0]) {		case 'update':
        $users->update();
        break;	
		case 'get_list':
        $users->get_list();
        break;	
		case 'get_it':
        $users->get_it();
        break;	
		case 'get_table':
        $users->get_table();
        break;	
		default:
            include('usersView.php');
        break;
}
$access_config = [
    'update'=>[
        'allow_action'=>[ADMIN,USER], 
        'deny_action'=>[GUEST], 
        'field_disallow_view'=>[ // эти поля не будут видны в интерфейсе у перечисленных ролей
            USER=>['pass_num'],
            ADMIN=>['phone'],
        ],
        'field_disallow_update'=>[ // эти поля будут запрещены к редактированию в интерфейсе у перечисленных ролей
            USER=>['pass_num'],
            ADMIN=>['phone'],
        ],
        'record_allow_update'=>[ // внести изменения в эти записи смогут только перечисленные роли или OWNER
            ADMIN,
            'OWNER' =>['user_id']
        ],
        'record_allow_view'=>[
            ADMIN,
            'OWNER' =>['user_id']
        ]
    ]
];
function check_action_allow($access_config, $action){ // проверяем разрешено ли вообше этой роли запускать action
    if(is_array($access_config) && is_string($action)){
        if(isset($access_config[$action])){
            if(isset($access_config[$action]['allow_action'])){
                if(!in_array($_SESSION["access_level"], $access_config[$action]['allow_action']))
                    return false;
            }
            if(isset($access_config[$action]['deny_action'])){
                if(in_array($_SESSION["access_level"], $access_config[$action]['deny_action']))
                    return false;
            }
            
        }
    }
    return true;
}
function check_record_allow_update($access_config, $action, $where_fields){ // проверяем разрешено ли роли редактировать запись, а если разрешено только владельцу, то добавляем во WHERE условие, что запись принадлежит текущему пользователю
    if(isset($access_config[$action]['record_allow_update'])){
        if(!in_array($_SESSION["access_level"], $access_config[$action]['record_allow_update'])){
            if(isset($access_config[$action]['record_allow_update']['OWNER'])){
                foreach($access_config[$action]['record_allow_update']['OWNER'] as $id_fields){
                    $where_fields[$id_fields] = $_SESSION["user_id"];
                }
                return $where_fields;
            }
            return false;
        }
        return true;
    }
}
function check_record_allow_view($access_config, $action, $where_fields){ // проверяем разрешено ли роли смотреть запись, а если разрешено только владельцу, то добавляем во WHERE условие, что запись принадлежит текущему пользователю
    if(isset($access_config[$action]['record_allow_view'])){
        if(!in_array($_SESSION["access_level"], $access_config[$action]['record_allow_view'])){
            if(isset($access_config[$action]['record_allow_view']['OWNER'])){
                foreach($access_config[$action]['record_allow_view']['OWNER'] as $id_fields){
                    $where_fields[$id_fields] = $_SESSION["user_id"];
                }
                return $where_fields;
            }
            return false;
        }
        return true;
    }
}
function filter_field_disallow_update($access_config, $action, $updated_data){ // проверяем, разрешено ли этой роли редактировать эти поля. Если нет - убираем эти поля из запроса на редактирование
    if(is_array($access_config) && is_string($action)){
        if(isset($access_config[$action])){
            if(isset($access_config[$action]['field_disallow_update'])){
              foreach($access_config[$action]['field_disallow_update'][$_SESSION["access_level"]] as $field=>$val){
                  if(isset($updated_data[$field])){
                      // TODO: в случае обнаружения заперещенных элементов нужно писать лог в журнал, это может свидетельствовать о попытке атаки
                      unset($updated_data[$field]);
                  }
                  
              }
            }
        }
    }
}
function filter_field_disallow_view($access_config, $action, $updated_data){ // проверяем, разрешено ли этой роли смотреть эти поля. Если нет - убираем эти поля из запроса на редактирование
    if(is_array($access_config) && is_string($action)){
        if(isset($access_config[$action])){
            if(isset($access_config[$action]['field_disallow_view'])){
              foreach($access_config[$action]['field_disallow_view'][$_SESSION["access_level"]] as $field=>$val){
                  if(isset($updated_data[$field])){
                      // TODO: в случае обнаружения заперещенных элементов нужно писать лог в журнал, это может свидетельствовать о попытке атаки
                      unset($updated_data[$field]);
                  }
                  
              }
            }
        }
    }
}
class users { 		function update () {
										global $db;
				$db = new db('localhost', 'cabinet-ingrid', 'cabinet-ingrid', 'cabinet-ingrid');
				$data['lcc'] = $_POST['lcc'];
$data['uname'] = $_POST['uname'];
$data['ufam'] = $_POST['ufam'];
$data['uoth'] = $_POST['uoth'];
$data['pass_num'] = $_POST['pass_num'];
$data['email'] = $_POST['email'];
$data['phone'] = $_POST['phone'];
				$db->update('users', $data, array('user_id'=>$_POST['user_id']));
						exit();
		}
			function get_table (){

			$db_settings = array(
				'rdbms' => 'MYSQLi',
				'db_server' => 'localhost',
				'db_user' => 'cabinet-ingrid',
				'db_passwd' => 'cabinet-ingrid',
				'db_name' => 'cabinet-ingrid',
				'db_port' => '3306',
				'charset' => 'utf8',
				'use_pst' => true,
				'pst_placeholder' => 'question_mark'
			);
			$ds = new dacapo($db_settings, null);
			
			
			$page_settings = array(
				"selectCountSQL" => "select count(*) as totalrows from `users`",  

				"selectSQL" => "select `user_id`, 
				`lcc`, `uname`, `ufam`, `uoth`, `pass_num`, `email`, `phone`, `user_id`				from `users`",
				"page_num" => $_POST['page_num'],
				"rows_per_page" => $_POST['rows_per_page'],
				"columns" => $_POST['columns'],
				"sorting" =>  isset($_POST['sorting']) ? $_POST['sorting'] : array(),
				"filter_rules" => isset($_POST['filter_rules']) ? $_POST['filter_rules'] : array()
			);
			$jfr = new jui_filter_rules($ds);
            $jdg = new bs_grid($ds, $jfr, $page_settings, $_POST['debug_mode'] == "yes" ? true : false);
            
            $data = $jdg->get_page_data();
            
            // data conversions (if necessary)
            foreach($data['page_data'] as $key => $row) {
            	// your code here
            
            										$row['actions'] .= "<button class=\"btn btn-primary btn-xs\" data-toggle=\"modal\" data-target=\"#updateModal\" data-url=\"\" data-whatever=\"{$row['user_id']}\"><i class=\"fa fa-clock\"></i></button>";
				              
                
                $data['page_data'][$key] = $row;
            
            }
            
            echo json_encode($data);
			exit();
		}
		function get_list () {
			global $URI_TO_CTL;
			global $db;
			$db = new db('localhost', 'cabinet-ingrid', 'cabinet-ingrid', 'cabinet-ingrid');

			  $users = $db->select('users'); 


			print json_encode($users, true);
			exit();
		}
		function get_it () {
			global $URI_TO_CTL;
			global $db;
			$db = new db('localhost', 'cabinet-ingrid', 'cabinet-ingrid', 'cabinet-ingrid');

			if($URI_TO_CTL[1]){
			  $users = $db->select('users', array('user_id'=>$URI_TO_CTL[1])); 
				print json_encode($users[0], true);
				exit();

			}
		}
}
