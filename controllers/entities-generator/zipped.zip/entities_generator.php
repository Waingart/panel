<?
// <<<<<<<<<< USERS ==========================================================================================
$AllEntitiesConfig['users']['access_config'] = [
	'get_table'=>[
        'allow_action'=>[ADMIN,USER], 
        'deny_action'=>[GUEST], 
        'field_disallow_view'=>[ // эти поля не будут видны в интерфейсе у перечисленных ролей
            USER=>['id'],
            ADMIN=>[],
        ],
        'field_disallow_update'=>[ // эти поля будут запрещены к редактированию в интерфейсе у перечисленных ролей
            USER=>['lcc', 'uname', 'ufam', 'uoth', 'pass_num', 'email', 'phone', 'password', 'access', 'salt', 'id'],
            ADMIN=>['lcc', 'id'],
        ],
        'record_allow_update'=>[ // внести изменения в эти записи смогут только перечисленные роли или OWNER
            ADMIN,
           // 'OWNER' =>['id']
        ],
        'record_allow_view'=>[
            ADMIN,
            'OWNER' =>['id']
        ]
    ],
	'get_it'=>[
        'allow_action'=>[ADMIN,USER], 
        'deny_action'=>[GUEST], 
        'field_disallow_view'=>[ // эти поля не будут видны в интерфейсе у перечисленных ролей
            USER=>['id'],
            ADMIN=>[],
        ],
        'field_disallow_update'=>[ // эти поля будут запрещены к редактированию в интерфейсе у перечисленных ролей
            USER=>['lcc', 'uname', 'ufam', 'uoth', 'pass_num', 'email', 'phone', 'password', 'access', 'salt', 'id'],
            ADMIN=>['lcc', 'id'],
        ],
        'record_allow_update'=>[ // внести изменения в эти записи смогут только перечисленные роли или OWNER
            ADMIN,
            // 'OWNER' =>['id']
        ],
        'record_allow_view'=>[
            ADMIN,
            'OWNER' =>['id']
        ]
    ],
    'update'=>[
        'allow_action'=>[ADMIN,USER], 
        'deny_action'=>[GUEST], 
        'field_disallow_view'=>[ // эти поля не будут видны в интерфейсе у перечисленных ролей
            USER=>['id'],
            ADMIN=>[],
        ],
        'field_disallow_update'=>[ // эти поля будут запрещены к редактированию в интерфейсе у перечисленных ролей
            USER=>['lcc', 'uname', 'ufam', 'uoth', 'pass_num', 'email', 'phone', 'password', 'access', 'salt', 'id'],
            ADMIN=>['lcc', 'id'],
        ],
        'record_allow_update'=>[ // внести изменения в эти записи смогут только перечисленные роли или OWNER
            ADMIN,
           // 'OWNER' =>['id']
        ],
        'record_allow_view'=>[
            ADMIN,
            'OWNER' =>['id']
        ]
    ],
    'modal_editor'=>[
        'allow_action'=>[ADMIN,USER], 
        'deny_action'=>[GUEST], 
        'field_disallow_view'=>[ // эти поля не будут видны в интерфейсе у перечисленных ролей
            USER=>[],
            ADMIN=>[],
        ],
        'field_disallow_update'=>[ // эти поля будут запрещены к редактированию в интерфейсе у перечисленных ролей
            USER=>['lcc', 'uname', 'ufam', 'uoth', 'pass_num', 'email', 'phone', 'password', 'access', 'salt', 'id'],
            ADMIN=>['id', 'lcc'],
        ]
    ]
];

$AllEntitiesConfig['users']['grid_config'] = array(
	'entitie' => 'users',
	'dbtable' => 'users',
	'id_field' => 'id',
	'visible_fields' => array('lcc', 'uname', 'ufam', 'uoth', 'pass_num', 'email', 'phone'),
	'title_fields' => array('lcc'=>'№ лицевого счета', 'uname'=>'Имя', 'ufam'=>'Фамилия', 'uoth'=>'Отчество', 'pass_num'=>'Серия и номер паспорта', 'email'=>'Email', 'phone'=>'Телефон'),
	//'size_fields' => array('pay_date'=>'2', 'amount'=>'2', 'pay_descr'=>'2', 'target'=>'2', 'inpay'=>'2'),
	/*'fields_formatting' => array(
			'target'=>array(1=>'Платежи исполнителям', 2=>'Личные расходы', 3=>'Орг. расходы'),
			'inpay'=>array(1=>'Приход', 2=>'Расход'),
	),*/
	//'tech_fields' => array('user_id'),
	'actions' => array('update'),
	'operations' => array(
	        'update' => array('bticon'=>'clock', 'title'=>'Изменить данные пользователя', 'url'=>'', 'modal_id'=>'updateModal'),
	),
	'modals' => array(
	    'updateModal' => array('title'=>'Изменить данные пользователя', 'type'=>0, 'content'=>'update.modal.html')
	)
);
$AllEntitiesConfig['users']['db_config'] = [
    'table' => 'users',
    'fields' =>[
        'id' => ['type'=>'int(11)', 'id'=>1, 'ai'=>1],
        'lcc' => ['type'=>'text', 'id'=>0],
		'password' => ['type'=>'text', 'id'=>0],
        'uname' => ['type'=>'text', 'id'=>0],
        'ufam' => ['type'=>'text', 'id'=>0],
        'uoth' => ['type'=>'text', 'id'=>0],
        'pass_num' => ['type'=>'text', 'id'=>0],
        'email' => ['type'=>'text', 'id'=>0],
        'phone' => ['type'=>'text', 'id'=>0],
		'salt' => ['type'=>'text', 'id'=>0],
		'access' => ['type'=>'int(11)', 'id'=>0]
    ]
];
$AllEntitiesConfig['users']['nav_config'] = [
    'menu_title' =>[ADMIN=>'Пользователи', USER=>'Мой профиль'] ,
    'url' => 'users',
    'url_access' => [ADMIN, USER]
];
// USERS >>>>>>>> =============================================================================================

// PAYMENTS <<<<<<<<< =========================================================================================

$AllEntitiesConfig['payments']['access_config'] = [
	'get_table'=>[
        'allow_action'=>[ADMIN,USER], 
        'deny_action'=>[GUEST], 
        'field_disallow_view'=>[ // эти поля не будут видны в интерфейсе у перечисленных ролей
            USER=>['id'],
            ADMIN=>[],
        ],
        'field_disallow_update'=>[ // эти поля будут запрещены к редактированию в интерфейсе у перечисленных ролей
            USER=>['id', 'docnum', 'sum', 'docnum', 'paydate', 'lcc', 'doc_id', 'status', 'user_id'],
            ADMIN=>['id', 'docnum', 'sum', 'docnum', 'paydate', 'lcc', 'doc_id', 'status', 'user_id'],
        ],
        'record_allow_update'=>[ // внести изменения в эти записи смогут только перечисленные роли или OWNER
            //ADMIN,
            //'OWNER' =>['user_id']
        ],
        'record_allow_view'=>[
            ADMIN,
            'OWNER' =>['user_id']
        ]
    ],'get_it'=>[
        'allow_action'=>[ADMIN,USER], 
        'deny_action'=>[GUEST], 
        'field_disallow_view'=>[ // эти поля не будут видны в интерфейсе у перечисленных ролей
            USER=>['id'],
            ADMIN=>[],
        ],
        'field_disallow_update'=>[ // эти поля будут запрещены к редактированию в интерфейсе у перечисленных ролей
            USER=>['id', 'docnum', 'sum', 'docnum', 'paydate', 'lcc', 'doc_id', 'status', 'user_id'],
            ADMIN=>['id', 'docnum', 'sum', 'docnum', 'paydate', 'lcc', 'doc_id', 'status', 'user_id'],
        ],
        'record_allow_update'=>[ // внести изменения в эти записи смогут только перечисленные роли или OWNER
            //ADMIN,
            //'OWNER' =>['user_id']
        ],
        'record_allow_view'=>[
            ADMIN,
            'OWNER' =>['user_id']
        ]
    ]
];

$AllEntitiesConfig['payments']['grid_config'] = array(
	'entitie' => 'payments',
	'dbtable' => 'payments',
	'id_field' => 'id',
	'visible_fields' => array('user_id', 'lcc', 'sum', 'docnum', 'paydate',  'doc_id', 'status'),
	'title_fields' => array('user_id'=>'Пользователь', 'lcc'=>'Л/С', 'sum'=>'Сумма', 'docnum'=>'№ квитанции', 'paydate'=>'Дата платежа', 'doc_id'=>'Квитанция', 'status' => 'Статус'),
	//'size_fields' => array('pay_date'=>'2', 'amount'=>'2', 'pay_descr'=>'2', 'target'=>'2', 'inpay'=>'2'),
	'fields_formatting' => array(
			'status'=>array(1=>'Успешно', 2=>'Ошибка!'),
	),
	//'tech_fields' => array('user_id'),
	'actions' => [],
	/*
	'operations' => array(
	        'update' => array('bticon'=>'clock', 'title'=>'Изменить данные пользователя', 'url'=>'', 'modal_id'=>'updateModal'),
	),
	'modals' => array(
	    'updateModal' => array('title'=>'Изменить данные пользователя', 'type'=>0, 'content'=>'update.modal.html')
	)
	*/
);

$AllEntitiesConfig['payments']['db_config'] = [
    'table' => 'payments',
    'fields' =>[
        'id' => ['type'=>'int(11)', 'id'=>1],
		'user_id' => ['type'=>'int(11)', 'id'=>0],
        'lcc' => ['type'=>'text', 'id'=>0],
        'sum' => ['type'=>'float', 'id'=>0],
        'doc_id' => ['type'=>'int(11)', 'id'=>0],
		'docnum' => ['type'=>'int(11)', 'id'=>0],
		'paydate' => ['type'=>'date', 'id'=>0],
		'status' => ['type'=>'int(11)', 'id'=>0],
    ]
];

$AllEntitiesConfig['payments']['nav_config'] = [
    'menu_title' =>[ADMIN=>'Платежи', USER=>'Мои платежи'] ,
    'url' => 'payments',
    'url_access' => [ADMIN, USER]
];
// PAYMENTS >>>>>>>>> =========================================================================================

// PAYDOCS <<<<<<<<< ==========================================================================================
/*

    Операции: оплатить, смотреть квитанцию без кнопки по ссылке
*/
// OK
$AllEntitiesConfig['paydocs']['access_config'] = [
	'get_table'=>[
        'allow_action'=>[ADMIN,USER], 
        'deny_action'=>[GUEST], 
        'field_disallow_view'=>[ // эти поля не будут видны в интерфейсе у перечисленных ролей
            USER=>['id', 'user_id', 'doc_id', 'lcc'],
            ADMIN=>[],
        ],
        'field_disallow_update'=>[ // эти поля будут запрещены к редактированию в интерфейсе у перечисленных ролей
            USER=>['id', 'docnum', 'docdate', 'sum', 'doc_id', 'user_id',  'lcc', 'status'],
            ADMIN=>['id', 'docnum', 'docdate', 'sum', 'doc_id', 'user_id',  'lcc', 'status'],
        ],
        'record_allow_update'=>[ // внести изменения в эти записи смогут только перечисленные роли или OWNER
            //ADMIN,
            //'OWNER' =>['user_id']
        ],
        'record_allow_view'=>[
            ADMIN,
            'OWNER' =>['user_id']
        ]
    ],
	'get_it'=>[
        'allow_action'=>[ADMIN,USER], 
        'deny_action'=>[GUEST], 
        'field_disallow_view'=>[ // эти поля не будут видны в интерфейсе у перечисленных ролей
            USER=>['id'],
            ADMIN=>[],
        ],
        'field_disallow_update'=>[ // эти поля будут запрещены к редактированию в интерфейсе у перечисленных ролей
            USER=>['id', 'docnum', 'sum', 'docnum', 'paydate', 'lcc', 'doc_id', 'status'],
            ADMIN=>['id', 'docnum', 'sum', 'docnum', 'paydate', 'lcc', 'doc_id', 'status'],
        ],
        'record_allow_update'=>[ // внести изменения в эти записи смогут только перечисленные роли или OWNER
            //ADMIN,
            //'OWNER' =>['user_id']
        ],
        'record_allow_view'=>[
            ADMIN,
            'OWNER' =>['user_id']
        ]
    ],
	'go_pay'=>[
		'allow_action'=>[USER], 
        'deny_action'=>[GUEST], 
	]
];

// OK
$AllEntitiesConfig['paydocs']['grid_config'] = array(
	'entitie' => 'paydocs',
	'dbtable' => 'paydocs',
	'id_field' => 'id',
	'visible_fields' => array('docnum', 'docdate', 'sum', 'user_id',  'lcc', 'status'),
	'title_fields' => array('docnum'=>'№ квитанции', 'docdate'=>'Дата квитанции', 'sum'=>'Сумма', 'user_id' => 'Пользователь',  'lcc'=>'Л/С', 'status' => 'Статус'),
	//'size_fields' => array('pay_date'=>'2', 'amount'=>'2', 'pay_descr'=>'2', 'target'=>'2', 'inpay'=>'2'),
	'fields_formatting' => array(
			'status'=>array(1=>'Оплачено', 2=>'Ошибка!', 3=>'Не оплачено',),
	),
	//'tech_fields' => array('user_id'),
	'actions' => [],
	/*
	'operations' => array(
	        'update' => array('bticon'=>'clock', 'title'=>'Изменить данные пользователя', 'url'=>'', 'modal_id'=>'updateModal'),
	),
	'modals' => array(
	    'updateModal' => array('title'=>'Изменить данные пользователя', 'type'=>0, 'content'=>'update.modal.html')
	)
	*/
);

//OK
$AllEntitiesConfig['paydocs']['db_config'] = [
    'table' => 'paydocs',
    'fields' =>[
        'id' => ['type'=>'int(11)', 'id'=>1],
        'lcc' => ['type'=>'text', 'id'=>0],
        'sum' => ['type'=>'float', 'id'=>0],
		'docnum' => ['type'=>'int(11)', 'id'=>0],
		'docdate' => ['type'=>'date', 'id'=>0],
		'user_id' => ['type'=>'int(11)', 'id'=>0],
		'status' => ['type'=>'int(11)', 'id'=>0],
    ]
];
$AllEntitiesConfig['paydocs']['nav_config'] = [
    'menu_title' =>[ADMIN=>'Квитанции', USER=>'Квитанции'] ,
    'url' => 'paydocs',
    'url_access' => [ADMIN, USER]
];
// PAYDOCS >>>>>>>>> ==========================================================================================

// REQUESTS <<<<<<<<< ==========================================================================================

// ok
$AllEntitiesConfig['requests']['access_config'] = [
	'get_table'=>[
        'allow_action'=>[ADMIN,USER], 
        'deny_action'=>[GUEST], 
        'field_disallow_view'=>[ // эти поля не будут видны в интерфейсе у перечисленных ролей
            USER=>['id', 'user_id', 'doc_id', 'lcc'],
            ADMIN=>[],
        ],
        'field_disallow_update'=>[ // эти поля будут запрещены к редактированию в интерфейсе у перечисленных ролей
            USER=>['id', 'req_subj', 'req_time', 'user_id', 'user_name', 'user_email'],
            ADMIN=>['id', 'req_subj', 'req_time', 'user_id', 'user_name', 'user_email'],
        ],
        'record_allow_update'=>[ // внести изменения в эти записи смогут только перечисленные роли или OWNER
            //ADMIN,
            //'OWNER' =>['user_id']
        ],
        'record_allow_view'=>[
            ADMIN,
            'OWNER' =>['user_id']
        ]
    ],
	'get_it'=>[
        'allow_action'=>[ADMIN,USER], 
        'deny_action'=>[GUEST], 
        'field_disallow_view'=>[ // эти поля не будут видны в интерфейсе у перечисленных ролей
            USER=>['id', 'user_id', 'user_name', 'user_email'],
            ADMIN=>[],
        ],
        'field_disallow_update'=>[ // эти поля будут запрещены к редактированию в интерфейсе у перечисленных ролей
            USER=>['id', 'req_subj', 'req_time', 'user_id', 'user_name', 'user_email'],
            ADMIN=>['id', 'req_subj', 'req_time', 'user_id', 'user_name', 'user_email'],
        ],
        'record_allow_update'=>[ // внести изменения в эти записи смогут только перечисленные роли или OWNER
            //ADMIN,
            //'OWNER' =>['user_id']
        ],
        'record_allow_view'=>[
            ADMIN,
            'OWNER' =>['user_id']
        ]
    ]
];

// ok
$AllEntitiesConfig['requests']['grid_config'] = array(
	'entitie' => 'requests',
	'dbtable' => 'requests',
	'id_field' => 'id',
	'visible_fields' => array('id', 'req_subj', 'req_time', 'user_id', 'user_name', 'user_email', 'status'),
	'title_fields' => array('id', 'req_subj' => 'Тема запроса', 'req_time' => 'Создан', 'user_id' => 'Пользователь', 'user_name' => 'Имя', 'user_email' => 'Email', 'status' => 'Статус'),
	//'size_fields' => array('pay_date'=>'2', 'amount'=>'2', 'pay_descr'=>'2', 'target'=>'2', 'inpay'=>'2'),
	'fields_formatting' => array(
			'status'=>array(1=>"Ожидает Вашего ответа", 2=>"Ожидает ответа сотрудника", 3=>"Завершен"),
	),
	//'tech_fields' => array('user_id'),
	'actions' => ['manager_answer', 'user_answer', 'close', 'reopen'],

	'operations' => array(
	        'close' => array('bticon'=>'clock', 'title'=>'Спасибо, проблема решена', 'url'=>'', 'modal_id'=>'closeModal'),
			'reopen' => array('bticon'=>'clock', 'title'=>'Возобновить диалог', 'url'=>'', 'modal_id'=>'reopenModal'),
	),
	'modals' => array(
	    'closeModal' => array('title'=>'Подтвердите действие', 'type'=>0, 'content'=>'update.modal.html'),
		'reopenModal' => array('title'=>'Подтвердите действие', 'type'=>0, 'content'=>'update.modal.html')
	)

);

// ok
$AllEntitiesConfig['requests']['db_config'] = [
    'table' => 'requests',
    'fields' =>[
        'id' => ['type'=>'int(11)', 'id'=>1],
		'req_subj' => ['type'=>'text', 'id'=>0],
        'req_time' => ['type'=>'datetime', 'id'=>0],
        'user_name' => ['type'=>'text', 'id'=>0],
		'user_email' => ['type'=>'text', 'id'=>0],
		'user_id' => ['type'=>'int(11)', 'id'=>0],
		'status' => ['type'=>'int(11)', 'id'=>0],
    ]
];
$AllEntitiesConfig['requests']['nav_config'] = [
    'menu_title' =>[ADMIN=>'Обращения', USER=>'Мои запросы'] ,
    'url' => 'requests',
    'url_access' => [ADMIN, USER]
];

// REQUESTS >>>>>>>>> ==========================================================================================



foreach($AllEntitiesConfig as $entitie => $EntitieConfig){
    $result_log = new EntitiesGenerator($EntitieConfig);
}

