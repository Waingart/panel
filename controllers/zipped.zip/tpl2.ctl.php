<?
print 'tpl2.ctl.php';