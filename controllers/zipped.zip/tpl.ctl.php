<?
print __DIR__.'/tpl/index.php';
$TPL = new TPL(__DIR__.'/tpl/index.php');
$TPL->run();