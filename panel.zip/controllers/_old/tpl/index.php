<?
print 'hello';