<?
include('chatView.php');