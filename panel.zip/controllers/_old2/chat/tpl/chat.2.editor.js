  $('#chat-box').slimScroll({
    height: '250px'
  });