<?
class Config {
    static $db_host = 'localhost';
    static $db_user = 'manager-abelar';
    static $db_pass = 'manager-abelar';
    static $db_name = 'manager-abelar';
}